package com.marufeb.controllers.util;

public enum Type {
    BACKPACK, LOCATION_ITEMS
}
