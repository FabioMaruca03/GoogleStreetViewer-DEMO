package com.marufeb.models.abstraction;

public interface Usable {
    boolean use();
}
