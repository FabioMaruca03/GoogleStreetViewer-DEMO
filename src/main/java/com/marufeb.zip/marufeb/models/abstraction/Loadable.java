package com.marufeb.models.abstraction;

public interface Loadable {
    boolean unload();
}
