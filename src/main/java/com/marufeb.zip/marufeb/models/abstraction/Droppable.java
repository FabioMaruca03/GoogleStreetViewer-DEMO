package com.marufeb.models.abstraction;

public interface Droppable {
    boolean drop();
}
